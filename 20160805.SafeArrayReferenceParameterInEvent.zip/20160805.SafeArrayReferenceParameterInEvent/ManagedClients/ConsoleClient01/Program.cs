﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestCOMServerLib;

namespace ConsoleClient01
{
    public class Program
    {
        static void DoTest1()
        {
            TestCOMClass testCOMObj = new TestCOMClass();
            // Comment out the event handler to not use.
            //testCOMObj.Event01 += TestCOMObj_Event01_Trivial;
            testCOMObj.Event01 += TestCOMObj_Event01_NonTrivial;
            testCOMObj.TestMethod01();
        }

        static void DoTest2()
        {
            TestCOMClass testCOMObj = new TestCOMClass();
            testCOMObj.Event02 += TestCOMObj_Event02;
            testCOMObj.TestMethod02();
        }

        static void DoTest3()
        {
            TestCOMClass testCOMObj = new TestCOMClass();
            testCOMObj.Event03 += TestCOMObj_Event03;
            testCOMObj.TestMethod03();
        }

        static void DoTest4()
        {
            TestCOMClass testCOMObj = new TestCOMClass();
            testCOMObj.Event04 += TestCOMObj_Event04;
            testCOMObj.TestMethod04();
        }

        // This version of the Event01 handler does nothing but simply returns.
        // This will cause the IDispatch::Invoke() call in TestCOMServer to 
        // return E_INVALIDARG.
        private static void TestCOMObj_Event01_Trivial(ref Array intArray)
        {
            return;
        }

        // This version of the Event01 handler attempt to modify the values
        // inside intArray.
        // When this event handler returns to the caller, the return HRESULT
        // is still E_INVALIDARG and the element values in the original
        // SAFEARRAY is not changed.
        private static void TestCOMObj_Event01_NonTrivial(ref Array intArray)
        {
            for (int i = 0; i < intArray.Length; i++)
            {
                intArray.SetValue((object)(i + 10), i);
            }
        }

        // This event handler is a good workaround for passing a 
        // referenced SAFEARRAY to managed code. The result will
        // be S_OK and the returned VARIANT will contain an updated
        // SAFEARRAY.
        //
        // However, the original SAFEARRAY will not be freed and
        // a memory leak will ensue.
        private static void TestCOMObj_Event02(ref object pvarArray)
        {
            int[] intArray = (int[])pvarArray;
            int i = 0;

            for (i = 0; i < intArray.Length; i++)
            {
                Console.WriteLine(intArray[i]);
                intArray[i] += 10;
            }

            int iCurrentSize = intArray.Length;

            Array.Resize<int>(ref intArray, iCurrentSize + 4);

            for (i = iCurrentSize; i < iCurrentSize + 4; i++)
            {
                intArray[i] = i;
            }

            pvarArray = (object)intArray;
        }

        // For a simple type like the VARIANT_BOOL, when passed
        // by reference, things work out OK. The VARIANT_BOOL
        // in the VARIANT parameter gets updated and return
        // changed accordingly.
        private static void TestCOMObj_Event03(ref bool pBool)
        {
            pBool = true;
            return;
        }

        // For the BSTR, when passed by reference, 
        // things work out only partially OK. The BSTR
        // in the VARIANT parameter gets updated and return
        // changed accordingly. But the original BSTR
        // does not get freed.
        private static void TestCOMObj_Event04(ref string pStr)
        {
            pStr = "World";
            return;
        }

        static void Main(string[] args)
        {
            DoTest1();
            DoTest2();
            DoTest3();
            DoTest4();
        }
    }
}
