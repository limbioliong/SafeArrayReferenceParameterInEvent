﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestCOMServerLib;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;

namespace ConsoleClient02
{
    // TestCOMClassEventsListener was my first attempt at a workaround
    // for the problem. I derived the TestCOMClassEventsListener
    // class from the event interface itself _ITestCOMClassEvents.
    // 
    // Then I connected an instance of TestCOMClassEventsListener to
    // the _ITestCOMClassEvents event connection point of an instance
    // of the TestCOMClass object.
    public class TestCOMClassEventsListener : _ITestCOMClassEvents
    {
        public TestCOMClassEventsListener(TestCOMClass testCOMObj)
        {
            IConnectionPointContainer icpc = (IConnectionPointContainer)testCOMObj;

            // Find the connection point for the
            // _ITestCOMClassEvents source interface.
            Guid guid = typeof(_ITestCOMClassEvents).GUID;
            icpc.FindConnectionPoint(ref guid, out icp);

            // Pass a pointer of this object to the connection point.
            icp.Advise(this, out iCookie);
        }

        ~TestCOMClassEventsListener()
        {
            if (iCookie != -1)
            {
                icp.Unadvise(iCookie);
                iCookie = -1;
            }
        }

        // This event handler does not help the problem of the return
        // value of E_INVALIDARG. Neither does it help in ensuring 
        // that modifications to the intArray gets passed back to 
        // the event caller.
        //
        // The eventualities are :
        //
        // 1. The return value from IDispatch::Invoke() on the client
        // side is E_NOINTERFACE.
        //
        // 2. Sometimes, the client (i.e. this application) can trigger
        // an exception after executing the event handler.
        //
        // 3. If all went well, the SAFEARRAY passed to IDispatch::Invoke() 
        // can become invalid. And this happens even if nothing is done 
        // to the array.
        //        
        [DispId(1)]
        public void Event01(ref Array intArray)
        {
            // Note that this event handler is trivial
            // and does nothing but return. Yet the SAFEARRAY
            // from the client side can become invalid.
            return;
        }

        // This event handler works correctly and may serve as a suitable 
        // workaround for the problem provided we use a VARIANT reference
        // as the parameter type.
        //
        // If a brand new SAFEARRAY is returned to the client, there is
        // evidence that the CLR will destroy the original SAFEARRAY.
        [DispId(2)]
        public void Event02(ref object pvarArray)
        {
            int[] intArray = (int[])pvarArray;
            int i = 0;

            // Increment each element by 10.
            for (i = 0; i < intArray.Length; i++)
            {
                intArray[i] += 10;
            }

            // Increase the size of the array.
            int iCurrentSize = intArray.Length;

            // Note that Array.Resize() will allocate a new array object
            // and intArray will be made to reference the new object.
            // See "Array.Resize<T> Method (T[], Int32)"
            // https://msdn.microsoft.com/en-us/library/bb348051(v=vs.110).aspx
            Array.Resize<int>(ref intArray, iCurrentSize + 4);

            // Set the value of each of the new elements.
            for (i = iCurrentSize; i < iCurrentSize + 4; i++)
            {
                intArray[i] = i;
            }

            // We have to assign the new intArray array back into the pvarArray object.
            // Otherwise the resized array will not be returned.
            pvarArray = (object)intArray;
        }

        // This event handler works correctly as expected.
        [DispId(3)]
        public void Event03(ref bool pBool)
        {
            // Simply set pBool to true.
            pBool = true;
            return;
        }

        // This event handler works correctly as expected.
        [DispId(4)]
        public void Event04(ref string pStr)
        {
            // Simply set pStr to a new string value.
            pStr = "World";
            return;
        }

        private IConnectionPoint icp = null;
        private int iCookie = -1;
    }
}
