﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestCOMServerLib;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;

namespace ConsoleClient02
{
    // The following definition of IDispatch is based on the code provided in
    // "CustomQueryInterface - IDispatch and Aggregation" (http://clrinterop.codeplex.com/releases/view/32350)
    /// <summary>
    /// This interface is the managed version of the native com IDispatch, it has the same vtable layout
    /// as well as the GUID of the native IDispatch interface.
    /// </summary>
    [ComImport]
    [Guid("00020400-0000-0000-C000-000000000046")]
    [InterfaceTypeAttribute(ComInterfaceType.InterfaceIsIUnknown)]    
    public interface IDispatch
    {        
        void GetTypeInfoCount(out uint pctinfo);

        void GetTypeInfo(uint iTInfo, int lcid, out IntPtr info);

        [PreserveSig]
        UInt32 GetIDsOfNames
        (
            ref Guid iid,
            [MarshalAs(UnmanagedType.LPArray, ArraySubType = UnmanagedType.LPWStr, SizeParamIndex = 2)]
            string[] names,
            int cNames,
            int lcid,
            [Out][MarshalAs(UnmanagedType.LPArray, ArraySubType = UnmanagedType.I4, SizeParamIndex = 2)]
            int[] rgDispId
        );

        void Invoke(
            int dispId,
            ref Guid riid,
            int lcid,
            ushort wFlags,
            ref System.Runtime.InteropServices.ComTypes.DISPPARAMS pDispParams,
            out object result,
            IntPtr pExcepInfo,
            IntPtr puArgErr);
    }

    class TestCOMClassEventsListener2 : IDispatch, ICustomQueryInterface
    {
        public const UInt32 DISP_E_NONAMEDARGS = 0x80020007;

        public TestCOMClassEventsListener2(TestCOMClass testCOMObj)
        {            
            IConnectionPointContainer icpc = (IConnectionPointContainer)testCOMObj;

            // Find the connection point for the
            // _ITestCOMClassEvents source interface.
            Guid guid = typeof(_ITestCOMClassEvents).GUID;
            icpc.FindConnectionPoint(ref guid, out icp);

            // Pass a pointer to the host to the connection point.
            icp.Advise(this, out iCookie);
        }

        ~TestCOMClassEventsListener2()
        {
            if (iCookie != -1)
            {
                icp.Unadvise(iCookie);
                iCookie = -1;
            }
        }

        #region IDispatch implementation
        public void GetTypeInfoCount(out uint pctinfo)
        {
            //NOT IMPLEMENTED
            pctinfo = 0;
        }

        public void GetTypeInfo(uint iTInfo, int lcid, out IntPtr info)
        {
            //NOT IMPLEMENTED
            info = IntPtr.Zero;
        }

        [PreserveSig]
        public UInt32 GetIDsOfNames
        (
            ref Guid iid,
            [MarshalAs(UnmanagedType.LPArray, ArraySubType = UnmanagedType.LPWStr, SizeParamIndex = 2)]
            string[] names,
            int cNames,
            int lcid,
            [Out][MarshalAs(UnmanagedType.LPArray, ArraySubType = UnmanagedType.I4, SizeParamIndex = 2)]
            int[] rgDispId
        )
        {
            UInt32 uiRet = 0;

            // ignore lcid, let's assume it is enu
            // Add strict check for parameters Here
            for (int i = 0; i < cNames; i++)
            {
                string name = names[i];

                switch(names[i])
                {
                    case "Event01" :
                        {
                            rgDispId[i] = 1;
                            break;
                        }

                    case "Event02" :
                        {
                            rgDispId[i] = 2;
                            break;
                        }

                    case "Event03" :
                        {
                            rgDispId[i] = 3;
                            break;
                        }

                    case "Event04" :
                        {
                            rgDispId[i] = 4;
                            break;
                        }

                    default:
                        {
                            rgDispId[i] = -1;
                            uiRet = DISP_E_NONAMEDARGS;
                            break;
                        }
                }
            }

            return uiRet;
        }

        public void Invoke
        (
            int dispId,
            ref Guid riid,
            int lcid,
            ushort wFlags,
            ref System.Runtime.InteropServices.ComTypes.DISPPARAMS pDispParams,
            out object result,
            IntPtr pExcepInfo,
            IntPtr puArgErr
        )
        {
            result = null;

            switch (dispId)
            {
                case 1:
                    {
                        // Comment out the unwanted event handler.
                        //result = HandleEvent01_v1(ref pDispParams);
                        result = HandleEvent01_v2(ref pDispParams);
                        break;
                    }

                case 2:
                    {
                        result = HandleEvent02(ref pDispParams);
                        break;
                    }

                case 3:
                    {
                        result = HandleEvent03(ref pDispParams);
                        break;
                    }

                case 4 :
                    {
                        result = HandleEvent04(ref pDispParams);
                        break;
                    }
            }

            return;
        }

        #endregion IDispatch implementation

        #region ICustomQueryInterface implementation
        public CustomQueryInterfaceResult GetInterface(ref Guid iid, out IntPtr ppv)
        {
            ppv = IntPtr.Zero;

            if (iid == typeof(_ITestCOMClassEvents).GUID)
            {
                // CustomQueryInterfaceMode.Ignore is used below to notify CLR to bypass the invocation of
                // ICustomQueryInterface.GetInterface to avoid infinite loop during QI.
                //
                // We return a pointer to this object's IDispatch interface to the caller.
                ppv = Marshal.GetComInterfaceForObject(this, typeof(IDispatch), CustomQueryInterfaceMode.Ignore);
                return CustomQueryInterfaceResult.Handled;
            }

            // Let CLR handle the rest of the QI
            return CustomQueryInterfaceResult.NotHandled;
        }

        #endregion

        // This event handler is not suitable for the problem at hand. 
        // It uses Marshal class methods to access the SAFEARRAY
        // from the VARIANT in the DISPPARAMS and store them in a managed array.
        // After manipulating the managed array, we attempt to store the values
        // of the managed array back into the SAFEARRAY in the VARIANT using
        // Marshal.GetNativeVariantForObject().
        //
        // However, this will not work because Marshal.GetNativeVariantForObject()
        // may create a new SAFEARRAY and store it in the VARIANT of type (VT_ARRAY | VT_I4).
        // This is not what the unmanaged COM server expects. The unmanaged COM
        // server expects the VARIANT to be of type (VT_I4 | VT_ARRAY | VT_BYREF).
        //
        // Note that this is not the fault of the Marshal.GetNativeVariantForObject()
        // method. It has done its job. There is just no way to tell it that we 
        // want it to store a reference to a SAFEARRAY instead of a direct SAFEARRAY.
        //
        // The other problem is that the original SAFEARRAY remains in memory and
        // does not get freed.
        private object HandleEvent01_v1(ref System.Runtime.InteropServices.ComTypes.DISPPARAMS pDispParams)
        {
            // We create an array of pointers to the VARIANTs inside the 
            // DISPPARAMS.
            IntPtr[] pVariantArray = new IntPtr[pDispParams.cArgs];

            IntPtr pVariantTemp = pDispParams.rgvarg;
            for (int i = 0; i < pDispParams.cArgs; i++)
            {
                pVariantArray[i] = pVariantTemp;
                pVariantTemp += Marshal.SizeOf(typeof(VariantStructGeneric));
            }

            // We access the reference to the SAFEARRAY in the first VARIANT and 
            // create a managed array from it.
            int[] array = Marshal.GetObjectForNativeVariant<int []>(pVariantArray[0]);

            // We modify the values in the managed array.
            for (int i = 0; i < array.Length; i++)
            {
                array.SetValue((object)(i + 10), i);
            }

            // We then extend the size of the managed array.
            // New elements will each be of value 0.
            int iSize = array.Length;

            Array.Resize<int>(ref array, iSize + 10);

            // This call to Marshal.GetNativeVariantForObject() unfortunately
            // will not make the original VARIANT contain a SAFEARRAY reference.
            // It will make the original VARIANT contain a direct SAFEARRAY.
            //
            // Note that this is not the fault of the Marshal.GetNativeVariantForObject()
            // method. It has done its job. There is just no way to tell it that we 
            // want it to store a reference to a SAFEARRAY instead of a direct SAFEARRAY.
            Marshal.GetNativeVariantForObject<int []>(array, pVariantArray[0]);

            return null;
        }

        [StructLayout(LayoutKind.Sequential)]
        struct SAFEARRAYBOUND
        {
            public UInt32 cElements;
            public Int32 lLbound;
        };

        [DllImport("OleAut32.dll", CallingConvention = CallingConvention.StdCall)]
        private static extern Int32 SafeArrayRedim([In] IntPtr psa, [In] SAFEARRAYBOUND [] psaboundNew);

        [DllImport("OleAut32.dll", CallingConvention = CallingConvention.StdCall)]
        private static extern Int32 SafeArrayGetUBound([In] IntPtr psa, [In] UInt32 nDim, [Out] out Int32 iUBoundReceiver);

        [DllImport("OleAut32.dll", CallingConvention = CallingConvention.StdCall)]
        private static extern Int32 SafeArrayGetLBound([In] IntPtr psa, [In] UInt32 nDim, [Out] out Int32 iLBoundReceiver);

        // This event handler is the suitable one for the problem at hand.
        // It directly uses unmanaged Windows APIs to manipulate the reference
        // to the SAFEARRAY contained in the VARIANT from the DISPPARAMS.
        //
        private object HandleEvent01_v2(ref System.Runtime.InteropServices.ComTypes.DISPPARAMS pDispParams)
        {
            // We create an array of VariantStructGeneric structs that will represent 
            // the VARIANTS as stored inside the DISPPARAMS.
            VariantStructGeneric[] vsg = new VariantStructGeneric[pDispParams.cArgs];

            IntPtr pVariantTemp = pDispParams.rgvarg;
            for (int i = 0; i < pDispParams.cArgs; i++)
            {
                vsg[i] = Marshal.PtrToStructure<VariantStructGeneric>(pVariantTemp);
                pVariantTemp += Marshal.SizeOf(typeof(VariantStructGeneric));
            }

            // We first access the address of the reference to the SAFEARRAY.
            IntPtr ppsa = vsg[0].variant_part.variant_union.pointer_data;
            // We then dereference this address to get to the actual SAFEARRAY.
            IntPtr psa = Marshal.PtrToStructure<IntPtr>(ppsa);

            Int32 iLBound = 0;
            Int32 iUBound = 0;

            // We then increase the size of the SAFEARRAY by 10 more elements.
            SafeArrayGetLBound(psa, 1, out iLBound);
            SafeArrayGetUBound(psa, 1, out iUBound);

            Int32 iSize = iUBound - iLBound + 1;

            SAFEARRAYBOUND[] rgsabound = new SAFEARRAYBOUND[1];

            rgsabound[0].lLbound = 0;
            rgsabound[0].cElements = (uint)(iSize + 10);

            SafeArrayRedim(psa, rgsabound);

            return null;
        }

        // This event handler also uses unmanaged Windows APIs to manipulate 
        // the SAFEARRAY contained in the reference VARIANT contained in the
        // DISPPARAMS.
        private object HandleEvent02(ref System.Runtime.InteropServices.ComTypes.DISPPARAMS pDispParams)
        {
            // We create an array of VariantStructGeneric structs that will represent 
            // the VARIANTS as stored inside the DISPPARAMS.
            VariantStructGeneric[] vsg = new VariantStructGeneric[pDispParams.cArgs];

            IntPtr pVariantTemp = pDispParams.rgvarg;
            for (int i = 0; i < pDispParams.cArgs; i++)
            {
                vsg[i] = Marshal.PtrToStructure<VariantStructGeneric>(pVariantTemp);
                pVariantTemp += Marshal.SizeOf(typeof(VariantStructGeneric));
            }

            // We first access the address of the reference to the VARIANT
            // contained in vsg[0].
            IntPtr pVar = vsg[0].variant_part.variant_union.pointer_data;
            // We then create a managed version of the unmanaged VARIANT.
            VariantStructGeneric Var = Marshal.PtrToStructure<VariantStructGeneric>(pVar);

            // Access the pointer to the SAFEARRAY.
            IntPtr psa = Var.variant_part.variant_union.pointer_data;

            Int32 iLBound = 0;
            Int32 iUBound = 0;

            // We then increase the size of the SAFEARRAY by 10 more elements.
            SafeArrayGetLBound(psa, 1, out iLBound);
            SafeArrayGetUBound(psa, 1, out iUBound);

            Int32 iSize = iUBound - iLBound + 1;

            SAFEARRAYBOUND[] rgsabound = new SAFEARRAYBOUND[1];

            rgsabound[0].lLbound = 0;
            rgsabound[0].cElements = (uint)(iSize + 10);

            SafeArrayRedim(psa, rgsabound);

            return null;
        }

        // This event handler directly access the pointer to the VARIANT_BOOL
        // in the VARIANT in the DISPPARAMS.
        private object HandleEvent03(ref System.Runtime.InteropServices.ComTypes.DISPPARAMS pDispParams)
        {
            // We create an array of VariantStructGeneric structs that will represent 
            // the VARIANTS as stored inside the DISPPARAMS.
            VariantStructGeneric[] vsg = new VariantStructGeneric[pDispParams.cArgs];

            IntPtr pVariantTemp = pDispParams.rgvarg;
            for (int i = 0; i < pDispParams.cArgs; i++)
            {
                vsg[i] = Marshal.PtrToStructure<VariantStructGeneric>(pVariantTemp);
                pVariantTemp += Marshal.SizeOf(typeof(VariantStructGeneric));
            }

            // Access the pointer to the VARIANT_BOOL which is a 16-bit value.
            IntPtr pBool = vsg[0].variant_part.variant_union.pointer_data;
            short sh = Marshal.PtrToStructure<short>(pBool);

            // Set the VARINAT_BOOL to VARIANT_TRUE.
            sh = -1;

            Marshal.StructureToPtr<short>(sh, pBool, false);

            return null;
        }

        // This event handler directly access the reference to the BSTR
        // in the VARIANT in the DISPPARAMS. Fortunately, there are adequate 
        // Marshal methods to manipulate BSTRs.
        private object HandleEvent04(ref System.Runtime.InteropServices.ComTypes.DISPPARAMS pDispParams)
        {
            // We create an array of VariantStructGeneric structs that will represent 
            // the VARIANTS as stored inside the DISPPARAMS.
            VariantStructGeneric[] vsg = new VariantStructGeneric[pDispParams.cArgs];

            IntPtr pVariantTemp = pDispParams.rgvarg;
            for (int i = 0; i < pDispParams.cArgs; i++)
            {
                vsg[i] = Marshal.PtrToStructure<VariantStructGeneric>(pVariantTemp);
                pVariantTemp += Marshal.SizeOf(typeof(VariantStructGeneric));
            }

            // Access the pointer to the BSTR.
            IntPtr pbstr = vsg[0].variant_part.variant_union.pointer_data;
            // Access the BSTR itself.
            IntPtr bstr = Marshal.PtrToStructure<IntPtr>(pbstr);

            // Create a managed string using the BSTR string.
            string str = Marshal.PtrToStringBSTR(bstr);
            // Completely modify the string.
            str = "Bye Bye World !";

            // Free the original BSTR.
            Marshal.FreeBSTR(bstr);
            // Create a brand new BSTR based on the string value 
            // inside str.
            bstr = Marshal.StringToBSTR(str);

            // Make the pointer to the BSTR point to the new BSTR.
            Marshal.StructureToPtr<IntPtr>(bstr, pbstr, false);

            return null;
        }

        private IConnectionPoint icp = null;
        private int iCookie = -1;
    }
}
