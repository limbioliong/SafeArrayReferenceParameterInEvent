﻿using System;
using System.Runtime.InteropServices;

namespace ConsoleClient02
{
    // The VariantStructGeneric structure is taken from 
    // "Defining a VARIANT Structure in Managed Code Part 2"
    // https://limbioliong.wordpress.com/2011/09/19/defining-a-variant-structure-in-managed-code-part-2/
    //
    [StructLayout(LayoutKind.Sequential)]
    public struct CY_internal_struct_01
    {
        public UInt32 Lo;
        public Int32 Hi;
    }

    [StructLayout(LayoutKind.Explicit)]
    public struct CY
    {
        [FieldOffset(0)]
        public CY_internal_struct_01 cy_internal_struct_01;
        [FieldOffset(0)]
        public long int64;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct __tagBRECORD
    {
        public IntPtr pvRecord;
        public IntPtr pRecInfo;
    }

    [StructLayout(LayoutKind.Explicit)]
    public struct VariantUnion
    {
        [FieldOffset(0)]
        public byte ubyte_data;  // This is the BYTE in C++.
        [FieldOffset(0)]
        public sbyte sbyte_data;  // This is the CHAR in C++.
        [FieldOffset(0)]
        public UInt16 uint16_data; // This is the USHORT in C++.
        [FieldOffset(0)]
        public Int16 int16_data;  // This is the SHORT in C++. Also used for the VARIANT_BOOL.
        [FieldOffset(0)]
        public UInt32 uint32_data; // This is the ULONG in C++. Also for the UINT.
        [FieldOffset(0)]
        public Int32 int32_data;  // This is the LONG in C++. Also used for the SCODE, the INT.
        [FieldOffset(0)]
        public ulong ulong_data;  // This is the ULONGLONG in C++.
        [FieldOffset(0)]
        public long long_data;   // This is the LONGLONG in C++.
        [FieldOffset(0)]
        public float float_data;  // This is the FLOAT in C++.
        [FieldOffset(0)]
        public double double_data; // This is the DOUBLE in C++. Also used for the DATE.
        [FieldOffset(0)]
        public IntPtr pointer_data;// Used for BSTR and all other pointer types.
        [FieldOffset(0)]
        public CY cy_data;  // This is the CY structure in C++.
        [FieldOffset(0)]
        public __tagBRECORD record_data; // This is the __tagBRECORD structure in C++.
    };

    [StructLayout(LayoutKind.Sequential)]
    public struct VariantStructure
    {
        public ushort vt;
        public ushort wReserved1;
        public ushort wReserved2;
        public ushort wReserved3;
        public VariantUnion variant_union;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct Decimal_internal_struct_01
    {
        public byte scale;
        public byte sign;
    }

    [StructLayout(LayoutKind.Explicit)]
    public struct Decimal_internal_union_01
    {
        [FieldOffset(0)]
        public Decimal_internal_struct_01 decimal_internal_struct_01;
        [FieldOffset(0)]
        public ushort signscale;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct Decimal_internal_struct_02
    {
        public UInt32 Lo32;
        public UInt32 Mid32;
    }

    [StructLayout(LayoutKind.Explicit)]
    public struct Decimal_internal_union_02
    {
        [FieldOffset(0)]
        public Decimal_internal_struct_02 decimal_internal_struct_02;
        [FieldOffset(0)]
        public ulong Lo64;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct DecimalStructure
    {
        public ushort wReserved;
        public Decimal_internal_union_01 decimal_internal_union_01;
        public UInt32 Hi32;
        public Decimal_internal_union_02 decimal_internal_union_02;
    }

    [StructLayout(LayoutKind.Explicit)]
    public struct VariantStructGeneric
    {
        [FieldOffset(0)]
        public VariantStructure variant_part;
        [FieldOffset(0)]
        public DecimalStructure decimal_part;
    }

}