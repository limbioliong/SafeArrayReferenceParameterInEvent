﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestCOMServerLib;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;

namespace ConsoleClient02
{    
    class Program
    {
        // DoTest1() uses the TestCOMClassEventsListener class for event handling
        // and then tests all events through calling the appropriate methods of
        // the TestCOMClass instance.
        static void DoTest1()
        {
            TestCOMClass testCOMObj = new TestCOMClass();

            TestCOMClassEventsListener listener = new TestCOMClassEventsListener(testCOMObj);
            testCOMObj.TestMethod01();
            testCOMObj.TestMethod02();
            testCOMObj.TestMethod03();
            testCOMObj.TestMethod04();
        }

        // DoTest2() uses the TestCOMClassEventsListener2 class for event handling
        // and then tests all events through calling the appropriate methods of
        // the TestCOMClass instance.
        static void DoTest2()
        {
            TestCOMClass testCOMObj = new TestCOMClass();
            TestCOMClassEventsListener2 listener = new TestCOMClassEventsListener2(testCOMObj);
            testCOMObj.TestMethod01();
            testCOMObj.TestMethod02();
            testCOMObj.TestMethod03();
            testCOMObj.TestMethod04();
        }

        // DoTestDelegate() will test the handling of Event02()
        // using the standard delegate method. The event handler
        // is TestCOMObj_Event02(). 
        //
        // The event handler will basically work but the original
        // SAFEARRAY passed in from the unmanaged server will not
        // get released. Resulting in a memory leak.
        static void DoTestDelegate()
        {
            TestCOMClass testCOMObj = new TestCOMClass();

            testCOMObj.Event02 += TestCOMObj_Event02;
            testCOMObj.TestMethod02();
        }

        // This event handler is a good workaround for passing a 
        // referenced SAFEARRAY to managed code. The result will
        // be S_OK and the returned VARIANT will contain an updated
        // SAFEARRAY.
        //
        // However, the original SAFEARRAY will not be freed and
        // a memory leak will ensue.
        private static void TestCOMObj_Event02(ref object pvarArray)
        {
            int[] intArray = (int[])pvarArray;
            int i = 0;

            // Increment each element by 10.
            for (i = 0; i < intArray.Length; i++)
            {
                intArray[i] += 10;
            }

            // Increase the size of the array.
            int iCurrentSize = intArray.Length;

            // Note that Array.Resize() will allocate a new array object
            // and intArray will be made to reference the new object.
            // See "Array.Resize<T> Method (T[], Int32)"
            // https://msdn.microsoft.com/en-us/library/bb348051(v=vs.110).aspx
            Array.Resize<int>(ref intArray, iCurrentSize + 4);

            // Set the value of each of the new elements.
            for (i = iCurrentSize; i < iCurrentSize + 4; i++)
            {
                intArray[i] = i;
            }

            // We have to assign the new intArray array back into the pvarArray object.
            // Otherwise the resized array will not be returned.
            pvarArray = (object)intArray;
        }

        static void Main(string[] args)
        {
            // Select the test method to use by commenting and uncommenting.
            DoTest1();
            //DoTest2();
            //DoTestDelegate();
            Console.ReadKey();
        }        
    }
}
