

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 8.00.0603 */
/* at Fri Aug 05 23:54:17 2016
 */
/* Compiler settings for TestCOMServer.idl:
    Oicf, W1, Zp8, env=Win32 (32b run), target_arch=X86 8.00.0603 
    protocol : dce , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
/* @@MIDL_FILE_HEADING(  ) */

#pragma warning( disable: 4049 )  /* more than 64k source lines */


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 475
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__


#ifndef __TestCOMServer_i_h__
#define __TestCOMServer_i_h__

#if defined(_MSC_VER) && (_MSC_VER >= 1020)
#pragma once
#endif

/* Forward Declarations */ 

#ifndef ___ITestCOMClassEvents_FWD_DEFINED__
#define ___ITestCOMClassEvents_FWD_DEFINED__
typedef interface _ITestCOMClassEvents _ITestCOMClassEvents;

#endif 	/* ___ITestCOMClassEvents_FWD_DEFINED__ */


#ifndef __ITestCOMClass_FWD_DEFINED__
#define __ITestCOMClass_FWD_DEFINED__
typedef interface ITestCOMClass ITestCOMClass;

#endif 	/* __ITestCOMClass_FWD_DEFINED__ */


#ifndef __TestCOMClass_FWD_DEFINED__
#define __TestCOMClass_FWD_DEFINED__

#ifdef __cplusplus
typedef class TestCOMClass TestCOMClass;
#else
typedef struct TestCOMClass TestCOMClass;
#endif /* __cplusplus */

#endif 	/* __TestCOMClass_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

#ifdef __cplusplus
extern "C"{
#endif 



#ifndef __TestCOMServerLib_LIBRARY_DEFINED__
#define __TestCOMServerLib_LIBRARY_DEFINED__

/* library TestCOMServerLib */
/* [version][uuid] */ 


EXTERN_C const IID LIBID_TestCOMServerLib;

#ifndef ___ITestCOMClassEvents_DISPINTERFACE_DEFINED__
#define ___ITestCOMClassEvents_DISPINTERFACE_DEFINED__

/* dispinterface _ITestCOMClassEvents */
/* [uuid] */ 


EXTERN_C const IID DIID__ITestCOMClassEvents;

#if defined(__cplusplus) && !defined(CINTERFACE)

    MIDL_INTERFACE("EA8F2DA8-FEA1-4E33-8248-5405FAAA17A7")
    _ITestCOMClassEvents : public IDispatch
    {
    };
    
#else 	/* C style interface */

    typedef struct _ITestCOMClassEventsVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            _ITestCOMClassEvents * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            _COM_Outptr_  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            _ITestCOMClassEvents * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            _ITestCOMClassEvents * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            _ITestCOMClassEvents * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            _ITestCOMClassEvents * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            _ITestCOMClassEvents * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            _ITestCOMClassEvents * This,
            /* [annotation][in] */ 
            _In_  DISPID dispIdMember,
            /* [annotation][in] */ 
            _In_  REFIID riid,
            /* [annotation][in] */ 
            _In_  LCID lcid,
            /* [annotation][in] */ 
            _In_  WORD wFlags,
            /* [annotation][out][in] */ 
            _In_  DISPPARAMS *pDispParams,
            /* [annotation][out] */ 
            _Out_opt_  VARIANT *pVarResult,
            /* [annotation][out] */ 
            _Out_opt_  EXCEPINFO *pExcepInfo,
            /* [annotation][out] */ 
            _Out_opt_  UINT *puArgErr);
        
        END_INTERFACE
    } _ITestCOMClassEventsVtbl;

    interface _ITestCOMClassEvents
    {
        CONST_VTBL struct _ITestCOMClassEventsVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define _ITestCOMClassEvents_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define _ITestCOMClassEvents_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define _ITestCOMClassEvents_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define _ITestCOMClassEvents_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define _ITestCOMClassEvents_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define _ITestCOMClassEvents_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define _ITestCOMClassEvents_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */


#endif 	/* ___ITestCOMClassEvents_DISPINTERFACE_DEFINED__ */


#ifndef __ITestCOMClass_INTERFACE_DEFINED__
#define __ITestCOMClass_INTERFACE_DEFINED__

/* interface ITestCOMClass */
/* [unique][nonextensible][dual][uuid][object] */ 


EXTERN_C const IID IID_ITestCOMClass;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("06926563-94D0-4386-B624-61799824CEDC")
    ITestCOMClass : public IDispatch
    {
    public:
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE TestMethod01( void) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE TestMethod02( void) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE TestMethod03( void) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE TestMethod04( void) = 0;
        
    };
    
    
#else 	/* C style interface */

    typedef struct ITestCOMClassVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            ITestCOMClass * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            _COM_Outptr_  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            ITestCOMClass * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            ITestCOMClass * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            ITestCOMClass * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            ITestCOMClass * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            ITestCOMClass * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            ITestCOMClass * This,
            /* [annotation][in] */ 
            _In_  DISPID dispIdMember,
            /* [annotation][in] */ 
            _In_  REFIID riid,
            /* [annotation][in] */ 
            _In_  LCID lcid,
            /* [annotation][in] */ 
            _In_  WORD wFlags,
            /* [annotation][out][in] */ 
            _In_  DISPPARAMS *pDispParams,
            /* [annotation][out] */ 
            _Out_opt_  VARIANT *pVarResult,
            /* [annotation][out] */ 
            _Out_opt_  EXCEPINFO *pExcepInfo,
            /* [annotation][out] */ 
            _Out_opt_  UINT *puArgErr);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE *TestMethod01 )( 
            ITestCOMClass * This);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE *TestMethod02 )( 
            ITestCOMClass * This);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE *TestMethod03 )( 
            ITestCOMClass * This);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE *TestMethod04 )( 
            ITestCOMClass * This);
        
        END_INTERFACE
    } ITestCOMClassVtbl;

    interface ITestCOMClass
    {
        CONST_VTBL struct ITestCOMClassVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ITestCOMClass_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define ITestCOMClass_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define ITestCOMClass_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define ITestCOMClass_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define ITestCOMClass_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define ITestCOMClass_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define ITestCOMClass_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 


#define ITestCOMClass_TestMethod01(This)	\
    ( (This)->lpVtbl -> TestMethod01(This) ) 

#define ITestCOMClass_TestMethod02(This)	\
    ( (This)->lpVtbl -> TestMethod02(This) ) 

#define ITestCOMClass_TestMethod03(This)	\
    ( (This)->lpVtbl -> TestMethod03(This) ) 

#define ITestCOMClass_TestMethod04(This)	\
    ( (This)->lpVtbl -> TestMethod04(This) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __ITestCOMClass_INTERFACE_DEFINED__ */


EXTERN_C const CLSID CLSID_TestCOMClass;

#ifdef __cplusplus

class DECLSPEC_UUID("7C597F5B-FED6-46BA-A49A-956F9339EA0D")
TestCOMClass;
#endif
#endif /* __TestCOMServerLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


