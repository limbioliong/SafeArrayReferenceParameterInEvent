// dllmain.h : Declaration of module class.

class CTestCOMServerModule : public ATL::CAtlDllModuleT< CTestCOMServerModule >
{
public :
	DECLARE_LIBID(LIBID_TestCOMServerLib)
	DECLARE_REGISTRY_APPID_RESOURCEID(IDR_TESTCOMSERVER, "{948A6CDB-CFAF-44C9-84E9-92A97C327E91}")
};

extern class CTestCOMServerModule _AtlModule;
