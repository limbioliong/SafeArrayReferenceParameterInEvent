// TestCOMClass.cpp : Implementation of CTestCOMClass

#include "stdafx.h"
#include "TestCOMClass.h"

// CTestCOMClass

STDMETHODIMP CTestCOMClass::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* const arr[] = 
	{
		&IID_ITestCOMClass
	};

	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}


STDMETHODIMP CTestCOMClass::TestMethod01()
{
	// TODO: Add your implementation code here
	HRESULT hr;
	SAFEARRAY* psa = NULL;
	SAFEARRAYBOUND rgsabound[1];

	rgsabound[0].lLbound = 0;
	rgsabound[0].cElements = 4;

	int intArray[] = { 1, 2, 3, 4 };

	psa = SafeArrayCreate(VT_I4, 1, rgsabound);

	for (int i = 0; i < 4; i++)
	{
		long ix[1];

		ix[0] = i;
		hr = SafeArrayPutElement(psa, ix, &(intArray[i]));
	}

	Fire_Event01(&psa);

	// psa was passed by reference.
	// If the client event handler wanted to modify it,
	// it has the responsibility to properly resize the array or
	// to destroy it and then re-allocate a new SAFEARRAY.
	// 
	// When we as the server receives the returned 
	// SAFEARRAY, it is the server's responsibility to later
	// SafeArrayDestroy() it.
	SafeArrayDestroy(psa);
	psa = NULL;

	return S_OK;
}


STDMETHODIMP CTestCOMClass::TestMethod02()
{
	// TODO: Add your implementation code here
	HRESULT hr;
	SAFEARRAY* psa = NULL;
	SAFEARRAYBOUND rgsabound[1];

	rgsabound[0].lLbound = 0;
	rgsabound[0].cElements = 4;

	int intArray[] = { 1, 2, 3, 4 };

	psa = SafeArrayCreate(VT_I4, 1, rgsabound);

	for (int i = 0; i < _countof(intArray); i++)
	{
		long ix[1];

		ix[0] = i;
		hr = SafeArrayPutElement(psa, ix, &(intArray[i]));
	}

	VARIANT var;

	VariantInit(&var);
	V_VT(&var) = VT_ARRAY | VT_I4;
	V_ARRAY(&var) = psa;

	Fire_Event02(&var);

	// If var is modified by client event handler code,
	// I can expect client to first call VariantClear().
	// psa should have been destroyed by the time Fire_Event02()
	// returns.
	// See : Passing a VARIANT Parameter by Reference.
	// https://social.msdn.microsoft.com/Forums/vstudio/en-US/6c9e9a9c-5178-4f30-aaeb-30c22edd037e/passing-a-variant-parameter-by-reference?forum=vcgeneral#6c9e9a9c-5178-4f30-aaeb-30c22edd037e
	// Hence psa need not be SafeArrayDestroy()'ed.
	/*
	SafeArrayDestroy(psa); 
	psa = NULL;	
	*/

	// However, the returned VARIANT is our responsibility.
	// Hence we should VariantClear() it.
	VariantClear(&var); 

	return S_OK;
}


STDMETHODIMP CTestCOMClass::TestMethod03()
{
	// TODO: Add your implementation code here
	VARIANT_BOOL vb = VARIANT_FALSE;

	// Simple types like the VARIANT_BOOL need not
	// be memory allocated first.
	Fire_Event03(&vb);

	return S_OK;
}


STDMETHODIMP CTestCOMClass::TestMethod04()
{
	// TODO: Add your implementation code here
	BSTR bstr = SysAllocString(L"Hello");

	// The BSTR type demonstrates a perfect case of 
	// mutual cooperation on the part of the server
	// and the client in terms of memory allocation.
	// 
	// If the client modifies the bstr parameter,
	// a different pointer is returned in bstr
	// when Fire_Event04() returns.
	//
	// This server will later SysFreeString() the
	// returned bstr and it can be assumed that
	// the client would have SysFreeString()'ed
	// the original one.
	Fire_Event04(&bstr);

	SysFreeString(bstr);
	bstr = NULL;

	return S_OK;
}
